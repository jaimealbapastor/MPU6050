--------------------------------------
	MPU6050 library & GUI
--------------------------------------

Project made by:
	Hugo 	DENIS--MARTIN
	Jaime	ALBA PASTOR

You can find the whole project in the GitHub repository:
https://github.com/jaimealbapastor/MPU6050

--------------------------------------

To install python requirements:

	py -m pip install -r ./interface/requirements.txt


To run GUI application:

	py ./interface/src/main.py

